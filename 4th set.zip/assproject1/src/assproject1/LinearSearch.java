package assproject1;

	import java.util.Scanner;

	public class LinearSearch {

		public static void main(String[] args) {
			// TODO Auto-generated method stub
			int[] arr = {1, 3, 5, 6, 7, 6, 8};
			System.out.println("Search for:");
			Scanner sc = new Scanner(System.in);
			int n = sc.nextInt();
			int index = linearSearch(arr, n);
			if (index != -1) {
				System.out.println("Element found at index " + index);
			} else {
				System.out.println("Element not found");
			}
		}

		public static int linearSearch(int[] arr, int n) {
			for (int i = 0; i < arr.length; i++) {
				if (arr[i] == n) {
					return i;
				}
			}
			return -1;
		}
	}

	


