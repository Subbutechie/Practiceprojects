package practiceproj;

public class overloadMethod {
	public void area(float b,float h) {
		System.out.println("area of rectangle : " +(b * h));
	}
	public void area(float r) {
		System.out.println("Area of circle : " + (3.14*r*r));
	}
	public static void main(String[] args) {
		overloadMethod ob = new overloadMethod();
		ob.area(2);
		ob.area(2, 1);
	}

}
