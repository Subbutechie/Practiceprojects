package practiceproj;
import java.util.Scanner;
// Declaring function
public class methodExecution {
	public int add(int x, int y) {
		int z = x + y;
		return z;
	}
	public static void main(String[] args) {
		System.out.println("Give the numbers to add : ");
		Scanner  read = new Scanner(System.in);
		// Taking Inputs
		int x = read.nextInt();
		int y = read.nextInt();
		methodExecution b = new methodExecution();
		int ans = b.add(x,y); // function calling

		System.out.println("sum :" + ans);
	}
	

}
 