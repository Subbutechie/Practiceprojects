package practiceproj2;
import practiceproj2.Apple;  // public access specifier
import practiceproj2.Mango;  // default access specifier
import practiceproj2.Orange; // private access specifier
import practiceproj2.grape;  // protected access specifier


public class AccessModifiers {
	public static void main(String[] args) {
		
		Apple apple1 = new Apple();
		
		// Access the price (declared as public in Apple.java)
		System.out.println("Apple 1 's price " + apple1.price );
		apple1.price = 200;
		System.out.println("Apple 1 's price " + apple1.price );
		
		
		Mango mango1 = new Mango();
		// Access the price (declared with no specifier in Mango.java)
		// Below statement will result 
		System.out.println("Mango 1 's price " + mango1.price ); 
		
		Orange orange1  = new Orange();
		// cannot access since the it is defined private
		//It will result in an error since it is private
		System.out.println("Orange's price " + orange1.price );
		
		
		grape grape1 = new grape();
		System.out.println("Price of grape " + grape1.price );
		
	}

}


