package practiceproj2;

public class Mango {
	int price = 200; // default access specifier

}
