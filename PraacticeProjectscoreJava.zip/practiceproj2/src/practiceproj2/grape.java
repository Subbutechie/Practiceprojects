package practiceproj2;

public class grape {
	protected int price = 120; // protected access specifier

}
