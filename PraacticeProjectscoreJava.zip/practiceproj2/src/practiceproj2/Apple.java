package practiceproj2;

public class Apple {

		public int price = 100; // public access specfier

}
