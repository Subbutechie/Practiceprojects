package practiceproj2;

public class Orange {
		
		private int price = 249; // private access specifier
		


}
