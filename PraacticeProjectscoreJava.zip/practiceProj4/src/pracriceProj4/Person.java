package pracriceProj4;
	
	public class Person {
	    private String name;
	    private int age;
	    
	    // Default constructor
	    public Person() {
	        this.name = "Unknown";
	        this.age = 0;
	    }
	    
	    // Constructor with parameters
	    public Person(String name, int age) {
	        this.name = name;
	        this.age = age;
	    }
	    
	    // Copy constructor
	    public Person(Person other) {
	        this.name = other.name;
	        this.age = other.age;
	    }
	    
	    // Getter and setter methods
	    public String getName() {
	        return this.name;
	    }
	    
	    public int getAge() {
	        return this.age;
	    }
	    
	    public void setName(String name) {
	        this.name = name;
	    }
	    
	    public void setAge(int age) {
	        this.age = age;
	    }
	    
	    // Main method to test the constructors
	    public static void main(String[] args) {
	        Person p1 = new Person(); // Default constructor
	        Person p2 = new Person("Alice", 25); // Constructor with parameters
	        Person p3 = new Person(p2); // Copy constructor
	        
	        System.out.println("p1: " + p1.getName() + ", " + p1.getAge());
	        System.out.println("p2: " + p2.getName() + ", " + p2.getAge());
	        System.out.println("p3: " + p3.getName() + ", " + p3.getAge());
	        
	        p1.setName("Bob");
	        p1.setAge(30);
	        
	        System.out.println("p1: " + p1.getName() + ", " + p1.getAge());
	        System.out.println("p2: " + p2.getName() + ", " + p2.getAge());
	        System.out.println("p3: " + p3.getName() + ", " + p3.getAge());
	    }
	}




