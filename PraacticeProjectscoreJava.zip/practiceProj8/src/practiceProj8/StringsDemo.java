package practiceProj8;

public class StringsDemo {
	public static void main(String[] args) {
		String str = new String("Hello World");
		System.out.println(str.length());
		
		//substring
		String sub = new String("Terminator");
		System.out.println(sub.substring(2));
		
		//String comparison
		String s1 = "hello";
		String s2 = "heldo";
		System.out.println(s1.compareTo(s2));
		
		//IsEmpty
		String s5 = "Hello";
		System.out.println(s5.isEmpty());
		
		//Lower case
		String s4 = "HUMAN";
		System.out.println(s4.toLowerCase());
		
		//replace
		String s6 = "HUMAN";
		String replace = s4.replace('H', 'S');
		System.out.println(replace);
		
		System.out.println("\n");
		// Creating stringBuffer and append method
		StringBuffer s = new StringBuffer("Welcome to Java");
		s.append("Enjoy your learning");
		System.out.println(s);
		
		//insert method
		s.insert(0, 'w');
		System.out.println(s);
		
		//String Builder
		StringBuilder sb1 = new StringBuilder("Happy");
		sb1.append("Learning");
		System.out.println(sb1);
		
		System.out.println(sb1.delete(0, 1));
		
		System.out.println(sb1.insert(1, "Welcome"));
		
		//conversion
		System.out.println("\n");
		System.out.println("Conversion of Strrings to StringBuffer and String Builder");
		
		String sl = "Hello";
		
		//conversion from String object to StringBuffer
		StringBuffer sbr = new StringBuffer(sl);
		sbr.reverse();
		System.out.println("String to StringBuffer");
		System.out.println(sbr);
		
		//Conversion from String Object to String Builder
		StringBuilder sbl = new StringBuilder(sl);
		sbl.reverse();
		System.out.println("String to StringBuffer");
		System.out.println(sbl);
		
		
	}

}
