package practiceproj7;

public class innerClassAssisted1 {
	private String msg = "Welcome to Java";
	
	class inner{
		void hello() {
			System.out.println(msg + ", Let's do it");
		}
	}


	public static void main(String[] args) {
		innerClassAssisted1 obj = new innerClassAssisted1();
		innerClassAssisted1.inner in = obj.new inner();
		in.hello();
	}	
}
