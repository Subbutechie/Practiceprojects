package practiceproj6;
import java.util.*;

public class MapDemo {
	public static void main(String[] args) {
		//HashMap
		HashMap<Integer,String> hm = new HashMap<Integer,String>();
		hm.put(1,"Raju");
		hm.put(2,"sara");
		hm.put(3,"casey");
		
		System.out.println("\nThe elements of hashmap are:");
		for (Map.Entry m:hm.entrySet()) {
			System.out.println(m.getKey()+" "+m.getValue());
		}
		//HashTable
		Hashtable<Integer,String> ht = new Hashtable<Integer,String>();
		ht.put(4,"simon");
		ht.put(5,"sam");
		ht.put(6,"sona");
		ht.put(7,"kira");
		
		System.out.println("\nThe elements of hashtable are:");
		for (Map.Entry n:ht.entrySet()) {
			System.out.println(n.getKey()+" "+n.getValue());
		}
		//Tree Map
		TreeMap<Integer,String> map = new TreeMap<Integer,String>();
		map.put(8,"king");
		map.put(9,"maran");
		map.put(10,"drake");
		
		System.out.println("\nThe elements of Treemap are:");
		for (Map.Entry I:map.entrySet()) {
			System.out.println(I.getKey()+" "+I.getValue());
		}
	}	
}
