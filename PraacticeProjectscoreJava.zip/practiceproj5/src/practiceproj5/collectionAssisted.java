package practiceproj5;
import java.util.*;

public class collectionAssisted {
	

	    public static void main(String[] args) {
	        
	        // Create an ArrayList
	        ArrayList<String> arrayList = new ArrayList<String>();
	        
	        // Add elements to the ArrayList
	        arrayList.add("apple");
	        arrayList.add("banana");
	        arrayList.add("orange");
	        
	        // Print the ArrayList
	        System.out.println("ArrayList:");
	        for(String fruit: arrayList) {
	            System.out.println(fruit);
	        }
	        
	        // Create a LinkedList
	        LinkedList<String> linkedList = new LinkedList<String>();
	        
	        // Add elements to the LinkedList
	        linkedList.add("dog");
	        linkedList.add("cat");
	        linkedList.add("bird");
	        
	        // Print the LinkedList
	        System.out.println("LinkedList:");
	        Iterator<String> iter = linkedList.iterator();
	        while(iter.hasNext()) {
	            System.out.println(iter.next());
	        }
	        
	        // Create a HashSet
	        HashSet<String> hashSet = new HashSet<String>();
	        
	        // Add elements to the HashSet
	        hashSet.add("apple");
	        hashSet.add("banana");
	        hashSet.add("orange");
	        
	        // Print the HashSet
	        System.out.println("HashSet:");
	        for(String fruit: hashSet) {
	            System.out.println(fruit);
	        }
	        
	        // Create a HashMap
	        HashMap<String, Integer> hashMap = new HashMap<String, Integer>();
	        
	        // Add elements to the HashMap
	        hashMap.put("apple", 1);
	        hashMap.put("banana", 2);
	        hashMap.put("orange", 3);
	        
	        // Print the HashMap
	        System.out.println("HashMap:");
	        for(String fruit: hashMap.keySet()) {
	            System.out.println(fruit + ": " + hashMap.get(fruit));
	        }
	    }
	


}
