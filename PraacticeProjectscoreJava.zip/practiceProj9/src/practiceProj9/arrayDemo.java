package practiceProj9;

public class arrayDemo {
	public static void main(String[] args) {
		
		//single-dimensional array
		int[] a = {10,4,56,89,20};
		for(int i = 0; i<5; i++) {
			System.out.println("Elements of array are " +a[i]);
		}
		
		//multidimensional array
		int[][] b = {
				{1,4,6,7},
				{2,4,7}
		};
		System.out.println("\n Length of row1 :" +b[1].length);
	}

}
