package assProj7;

import java.io.*;

	public class FileOperationsDemo {

	    public static void main(String[] args) {
	        FileOperationsDemo demo = new FileOperationsDemo();
	        String fileName = "data.txt";

	        // Create a new file
	        demo.createFile(fileName);

	        // Write data to the file
	        demo.writeFile(fileName, "Hello, World!");

	        // Read data from the file
	        String data = demo.readFile(fileName);
	        System.out.println("File Content: " + data);

	        // Update the file content
	        demo.updateFile(fileName, "Updated content!");

	        // Read the updated data from the file
	        data = demo.readFile(fileName);
	        System.out.println("Updated File Content: " + data);

	        // Delete the file
	        demo.deleteFile(fileName);
	    }

	    public void createFile(String fileName) {
	        File file = new File(fileName);

	        try {
	            if (file.createNewFile()) {
	                System.out.println("File created: " + fileName);
	            } else {
	                System.out.println("File already exists.");
	            }
	        } catch (IOException e) {
	            System.out.println("An error occurred while creating the file: " + e.getMessage());
	        }
	    }

	    public void writeFile(String fileName, String content) {
	        try (FileWriter writer = new FileWriter(fileName)) {
	            writer.write(content);
	            System.out.println("Data written to the file.");
	        } catch (IOException e) {
	            System.out.println("An error occurred while writing to the file: " + e.getMessage());
	        }
	    }

	    public String readFile(String fileName) {
	        StringBuilder content = new StringBuilder();

	        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
	            String line;
	            while ((line = reader.readLine()) != null) {
	                content.append(line);
	            }
	        } catch (IOException e) {
	            System.out.println("An error occurred while reading the file: " + e.getMessage());
	        }

	        return content.toString();
	    }

	    public void updateFile(String fileName, String content) {
	        try (FileWriter writer = new FileWriter(fileName, false)) {
	            writer.write(content);
	            System.out.println("File updated.");
	        } catch (IOException e) {
	            System.out.println("An error occurred while updating the file: " + e.getMessage());
	        }
	    }

	    public void deleteFile(String fileName) {
	        File file = new File(fileName);

	        if (file.delete()) {
	            System.out.println("File deleted: " + fileName);
	        } else {
	            System.out.println("Failed to delete the file.");
	        }
	    }
	}

	
		

	


