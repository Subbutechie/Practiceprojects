package Assproj1;

public class Runlnterface implements Runnable {
    @Override
    public void run() {
        // Code to be executed in a separate thread
    	System.out.println("start() calls to execute code in run()");
    }


    public static void main(String[] args) {
        // Create an instance of your Runnable class
        Runlnterface myRunnable = new Runlnterface();
        
        // Create a Thread object and pass your Runnable instance to it
        Thread thread = new Thread(myRunnable);
        
        // Start the thread
        thread.start();
        
        // Code in the main thread continues to execute concurrently with the new thread
        System.out.println("Main thread is still running");
    }

}