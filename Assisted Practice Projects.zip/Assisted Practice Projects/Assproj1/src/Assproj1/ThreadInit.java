package Assproj1;

// creating a thread using extend Thread
	public class  ThreadInit extends Thread {
		public void run() {
			System.out.println("This thread is running");
		}
	
		public static void main(String[] args) {
			ThreadInit mt = new ThreadInit();
			mt.start();
		}
	}

