package Assproj5;

public class ThrowsDemo {
	public static void main(String[] args) {
		
		class1 c1 = new class1();
		try{
		c1.division();
		}
		catch(Exception e) {
			System.out.println("Exception occured:" +e);
		}
				
		
	}

}
//// Author of class1 is saying that he wont 
// handle the exception for the statements
// in this method.
// Author wants the caller to handle the exception
// when he/she invokes this method

class class1{
	
	void division() throws ArithmeticException{
		int a =88, b =0 , rs;
		rs = a/b;
		System.out.println("Division:" +rs);
	}
	
	
}
