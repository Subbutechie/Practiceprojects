package Assproj5;


	
	//To throw an custom exception use extends Exception
	//then MyExceptionDemo class becomes an exception class
	//Because Exception is  the super class of all exceptions


public class MyExceptionDemo extends Exception {
	String message;

	MyExceptionDemo(String str2) {
		this.message = str2;
	}
	public String getMessage(){
		return this.message;
	}

}


	
