package Assproj5;

public class CustomExceptionDemo {
	public static void main(String[] args) {
		  
		System.out.println("Custom Exception Demo");
		CustomExceptionDemo custom1 = new CustomExceptionDemo();
		
		
		try {
			custom1.method1(15);
			
			custom1.method1(5);
			
		} catch (MyExceptionDemo e) {
			
			System.out.println("Exception happened : "+e.getMessage());
		}
		
	}

		
	
	public void method1(int x) throws MyExceptionDemo{
		if(x==5) {
			throw new MyExceptionDemo("Input 5 is not allowed");
		}
		else System.out.println("Thank your input" +x); 
			
	}

}
