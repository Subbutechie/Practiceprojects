package Assproj5;

public class FinallyDemo {

	public static void main(String[] args) {
		//Finally clause demo
		// We can have many catch blocks for a single try block
		//RULE: catch subclass exception first and then the super class exception
		int a =88, b =0 , result;
		try {
			result = a/b;
		}
		catch(ArithmeticException Ex) {
			System.out.println("Error:" +Ex.getMessage());
		}
		catch(NullPointerException e) {
			System.out.println("Error:" +e.getMessage());
		}
		finally {
			System.out.println("Always executes");
		}
	}

}
