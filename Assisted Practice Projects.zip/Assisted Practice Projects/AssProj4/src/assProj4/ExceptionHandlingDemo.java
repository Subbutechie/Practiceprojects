package assProj4;

	public class ExceptionHandlingDemo {

	    public static void main(String[] args) {
	        ExceptionHandlingDemo demo = new ExceptionHandlingDemo();
	        demo.divideNumbers(10, 0); // Example of catching an exception
	        demo.divideNumbers(20, 5); // Example of normal execution
	    }

	    public void divideNumbers(int dividend, int divisor) {
	        try {
	            int result = dividend / divisor;
	            System.out.println("Result: " + result);
	        } catch (ArithmeticException e) {
	            System.out.println("Error: Division by zero!");
	        }
	    }
	}



