package AssProj8;

	// Abstract class
	abstract class Shape {
	    // Abstract method
	    public abstract void draw();

	    // Concrete method
	    public void display() {
	        System.out.println("Displaying shape...");
	    }
	}

	// Concrete subclass
	class Circle extends Shape {
	    @Override
	    public void draw() {
	        System.out.println("Drawing a circle...");
	    }
	}

	// Concrete subclass
	class Rectangle extends Shape {
	    @Override
	    public void draw() {
	        System.out.println("Drawing a rectangle...");
	    }
	

	
	    
	}



