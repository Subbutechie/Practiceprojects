package AssProj8;

public class AbstractionDemo {
	    public static void main(String[] args) {
	        Shape circle = new Circle();
	        Shape rectangle = new Rectangle();

	        circle.draw(); // Calls the overridden draw() method in Circle class
	        circle.display(); // Calls the inherited display() method from the Shape class

	        rectangle.draw(); // Calls the overridden draw() method in Rectangle class
	        rectangle.display(); // Calls the inherited display() method from the Shape class

}
}