package asspProj3;

	public class SynchronizationDemo {

	    public static void main(String[] args) {
	        SynchronizationDemo demo = new SynchronizationDemo();
	        demo.run();
	    }

	    public void run() {
	        Counter counter = new Counter();

	        Thread t1 = new Thread(new IncrementThread(counter));
	        Thread t2 = new Thread(new DecrementThread(counter));

	        t1.start();
	        t2.start();

	        try {
	            t1.join();
	            t2.join();
	        } catch (InterruptedException e) {
	            e.printStackTrace();
	        }

	        System.out.println("Final count: " + counter.getCount());
	    }

	    static class Counter {
	        private int count;

	        public synchronized void increment() {
	            count++;
	        }

	        public synchronized void decrement() {
	            count--;
	        }

	        public synchronized int getCount() {
	            return count;
	        }
	    }

	    static class IncrementThread implements Runnable {
	        private Counter counter;

	        public IncrementThread(Counter counter) {
	            this.counter = counter;
	        }

	        @Override
	        public void run() {
	            for (int i = 0; i < 10000; i++) {
	                counter.increment();
	            }
	        }
	    }

	    static class DecrementThread implements Runnable {
	        private Counter counter;

	        public DecrementThread(Counter counter) {
	            this.counter = counter;
	        }

	        @Override
	        public void run() {
	            for (int i = 0; i < 10000; i++) {
	                counter.decrement();
	            }
	        }
	    }
	}


