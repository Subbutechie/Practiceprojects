/**
 * 
 */
/**
 * @author pudur
 *
 */
module Assproj6 {
}