package Assproj6;
import java.math.*;

public class ExceptionHandling {

	public static void main(String[] args) {
		System.out.println("Exception Handling program starts from here");
		try {
			//uncommenting will throw for arithmetic exception
			double i = Math.sqrt(0/0);
			System.out.println("Square root:" +i);
			
			// uncommenting for Array Indexoutofbounds exception
			//int[] arr = {1,45,77,44,77};
			//System.out.println("element : " +arr[9]);
			
			//uncommenting will throw  null pointer exception
			//String str = null;
			//System.out.println(str.length());
		}
		catch(ArithmeticException e) {
			System.out.println("Dividing with zero is undefined");
			System.out.println("error:" +e);
		}
		catch(ArrayIndexOutOfBoundsException e) {
			System.out.println("User is trying to access out of the index location");
			System.out.println("error:" +e);
		}
		catch(NullPointerException e) {
			System.out.println("user is trying to perform operations on null value");
			System.out.println("error:" +e);
		}
		finally {
			System.out.println("this block always executes");
		}
		System.out.println("Exception program ends here");

	}

}
