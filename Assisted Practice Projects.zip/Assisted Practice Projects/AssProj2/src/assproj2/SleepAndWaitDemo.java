package assproj2;

	public class SleepAndWaitDemo {

	    public static void main(String[] args) {
	        SleepAndWaitDemo demo = new SleepAndWaitDemo();
	        demo.run();
	    }

	    public void run() {
	        Thread t1 = new Thread(new SleepThread());
	        Thread t2 = new Thread(new WaitThread());

	        t1.start();
	        t2.start();
	    }

	    class SleepThread implements Runnable {

	        @Override
	        public void run() {
	            synchronized (this) {
	                try {
	                    System.out.println("SleepThread is starting...");
	                    Thread.sleep(3000); // Sleep for 3 seconds
	                    System.out.println("SleepThread has woken up.");
	                } catch (InterruptedException e) {
	                    e.printStackTrace();
	                }
	            }
	        }
	    }

	    class WaitThread implements Runnable {

	        @Override
	        public void run() {
	            synchronized (this) {
	                try {
	                    System.out.println("WaitThread is starting...");
	                    wait(3000); // Wait for 3 seconds
	                    System.out.println("WaitThread has woken up.");
	                } catch (InterruptedException e) {
	                    e.printStackTrace();
	                }
	            }
	        }
	    }
	}



