package Proj5;
	
	class Node {
	    int data;
	    Node next;

	    Node(int data) {
	        this.data = data;
	        this.next = null;
	    }
	}

	public class LinkedList {
	    Node head;

	    void deleteFirstOccurrence(int key) {
	        if (head == null) {
	            return;
	        }

	        // If the key is at the head node
	        if (head.data == key) {
	            head = head.next;
	            return;
	        }

	        Node prev = null;
	        Node curr = head;

	        while (curr != null && curr.data != key) {
	            prev = curr;
	            curr = curr.next;
	        }

	        // If key is found, delete the node
	        if (curr != null) {
	            prev.next = curr.next;
	        }
	    }

	    void insert(int data) {
	        Node newNode = new Node(data);
	        if (head == null) {
	            head = newNode;
	        } else {
	            Node temp = head;
	            while (temp.next != null) {
	                temp = temp.next;
	            }
	            temp.next = newNode;
	        }
	    }

	    void display() {
	        Node curr = head;
	        while (curr != null) {
	            System.out.print(curr.data + " ");
	            curr = curr.next;
	        }
	        System.out.println();
	    }

	    public static void main(String[] args) {
	        LinkedList list = new LinkedList();

	        list.insert(1);
	        list.insert(2);
	        list.insert(3);
	        list.insert(4);
	        list.insert(5);

	        System.out.println("Original linked list:");
	        list.display();

	        int key = 3;
	        list.deleteFirstOccurrence(key);

	        System.out.println("Linked list after deleting first occurrence of key " + key + ":");
	        list.display();
	    }
	}



