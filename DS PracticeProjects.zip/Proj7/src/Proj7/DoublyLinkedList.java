package Proj7;
	
	class Node {
	    int data;
	    Node prev;
	    Node next;

	    Node(int data) {
	        this.data = data;
	        this.prev = null;
	        this.next = null;
	    }
	}

	public class DoublyLinkedList {
	    Node head;

	    void insert(int data) {
	        Node newNode = new Node(data);

	        if (head == null) {
	            head = newNode;
	        } else {
	            Node temp = head;
	            while (temp.next != null) {
	                temp = temp.next;
	            }
	            temp.next = newNode;
	            newNode.prev = temp;
	        }
	    }

	    void traverseForward() {
	        Node curr = head;

	        System.out.println("Doubly linked list in forward direction:");
	        while (curr != null) {
	            System.out.print(curr.data + " ");
	            curr = curr.next;
	        }
	        System.out.println();
	    }

	    void traverseBackward() {
	        Node curr = head;

	        // Traverse to the last node
	        while (curr != null && curr.next != null) {
	            curr = curr.next;
	        }

	        System.out.println("Doubly linked list in backward direction:");
	        while (curr != null) {
	            System.out.print(curr.data + " ");
	            curr = curr.prev;
	        }
	        System.out.println();
	    }

	    public static void main(String[] args) {
	        DoublyLinkedList list = new DoublyLinkedList();

	        list.insert(1);
	        list.insert(2);
	        list.insert(3);
	        list.insert(4);
	        list.insert(5);

	        list.traverseForward();
	        list.traverseBackward();
	    }
	}



