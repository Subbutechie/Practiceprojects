package Proj8;
	
	import java.util.Stack;

	public class StackExample {
	    public static void main(String[] args) {
	        Stack<Integer> stack = new Stack<>();

	        // Insert elements into the stack
	        stack.push(1);
	        stack.push(2);
	        stack.push(3);

	        System.out.println("Stack elements: " + stack);

	        // Remove elements from the stack
	        int topElement = stack.pop();
	        System.out.println("Popped element: " + topElement);
	        System.out.println("Stack elements after popping: " + stack);

	        // Insert another element into the stack
	        stack.push(4);
	        System.out.println("Stack elements after pushing: " + stack);

	        // Remove the top element without retrieving it
	        stack.pop();
	        System.out.println("Stack elements after popping without retrieval: " + stack);

	        // Check if the stack is empty
	        boolean isEmpty = stack.isEmpty();
	        System.out.println("Is the stack empty? " + isEmpty);

	        // Get the top element without removing it
	        int peekElement = stack.peek();
	        System.out.println("Top element: " + peekElement);
	    }
	}



