package Proj2;
	
	import java.util.Arrays;
	import java.util.List;

	public class FourthSmallestElement {

	    public static int findFourthSmallest(List<Integer> list) {
	        if (list == null || list.size() < 4) {
	            throw new IllegalArgumentException("List must contain at least four elements");
	        }

	        Integer[] sortedArray = list.toArray(new Integer[0]);
	        Arrays.sort(sortedArray);
	        return sortedArray[3];
	    }

	    public static void main(String[] args) {
	        List<Integer> elements = Arrays.asList(9, 4, 2, 7, 1, 5, 8, 3, 6);
	        int fourthSmallest = findFourthSmallest(elements);
	        System.out.println("Fourth smallest element: " + fourthSmallest);
	    }
	}



