/**
 * 
 */
/**
 * @author pudur
 *
 */
module RotateArray {
}