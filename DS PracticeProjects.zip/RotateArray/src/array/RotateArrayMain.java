package array;

import java.util.Arrays;



public class RotateArrayMain {

	public static void main(String[] args) {
		int[] arr= {2, 5, 8 , 7, 6, 3 };
		
		int k = 5;
		
		System.out.println("ORIGINAL ARRAY: " + Arrays.toString(arr));
		
		rotateArrayByKPositions(arr, k);		
		
		System.out.println("RESULT: " + Arrays.toString(arr));

	}
	private static void rotateArrayByKPositions(int[] arr, int k) {
		int n = arr.length;
		
		//special case when we are to rotate more than the size of the array.
		if(k>n)
			k = k % n;
		
		//initialize the result array
		int[] result = new int[n];
		
		// place the k rotated elements in the result array
		for (int i=0;i<k;i++){
			result[i]= arr[n-k+i];
		};
		
		//System.out.println(Arrays.toString(result));
		
		// append the starting elements of the original array
		// in the  n-k positions of result array 
		int j=0;
		for(int i=k; i<result.length; i++) {
			result[i] =  arr[j++];
		};
		
		//System.out.println(Arrays.toString(result));
		
		System.arraycopy( result, 0, arr, 0, arr.length );			
	}
	
}  
