package Proj9;
	
	import java.util.LinkedList;
	import java.util.Queue;

	public class QueueExample {
	    public static void main(String[] args) {
	        Queue<Integer> queue = new LinkedList<>();

	        // Insert elements into the queue
	        queue.offer(1);
	        queue.offer(2);
	        queue.offer(3);

	        System.out.println("Queue elements: " + queue);

	        // Remove elements from the queue
	        int frontElement = queue.poll();
	        System.out.println("Removed element: " + frontElement);
	        System.out.println("Queue elements after polling: " + queue);

	        // Insert another element into the queue
	        queue.offer(4);
	        System.out.println("Queue elements after offering: " + queue);

	        // Remove the front element without retrieving it
	        queue.poll();
	        System.out.println("Queue elements after polling without retrieval: " + queue);

	        // Check if the queue is empty
	        boolean isEmpty = queue.isEmpty();
	        System.out.println("Is the queue empty? " + isEmpty);

	        // Get the front element without removing it
	        int peekElement = queue.peek();
	        System.out.println("Front element: " + peekElement);
	    }
	}



