package Proj6;

	class Node {
	    int data;
	    Node next;

	    Node(int data) {
	        this.data = data;
	        this.next = null;
	    }
	}

	public class CircularLinkedList {
	    Node head;

	    void insert(int data) {
	        Node newNode = new Node(data);

	        // If the list is empty
	        if (head == null) {
	            head = newNode;
	            newNode.next = head;
	        }
	        // If the new node should be inserted before the head
	        else if (data <= head.data) {
	            Node temp = head;
	            while (temp.next != head) {
	                temp = temp.next;
	            }
	            temp.next = newNode;
	            newNode.next = head;
	            head = newNode;
	        }
	        // If the new node should be inserted at some position within the list
	        else {
	            Node curr = head;
	            while (curr.next != head && curr.next.data < data) {
	                curr = curr.next;
	            }
	            newNode.next = curr.next;
	            curr.next = newNode;
	        }
	    }

	    void display() {
	        if (head == null) {
	            return;
	        }

	        Node curr = head;
	        do {
	            System.out.print(curr.data + " ");
	            curr = curr.next;
	        } while (curr != head);
	        System.out.println();
	    }

	    public static void main(String[] args) {
	        CircularLinkedList list = new CircularLinkedList();

	        // Insert elements in a sorted manner
	        list.insert(1);
	        list.insert(3);
	        list.insert(5);
	        list.insert(7);

	        System.out.println("Original circular linked list:");
	        list.display();

	        // Insert a new element
	        int newElement = 4;
	        list.insert(newElement);

	        System.out.println("Circular linked list after inserting " + newElement + ":");
	        list.display();
	    }
	}



