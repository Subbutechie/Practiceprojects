package com;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

@WebServlet("/op")
public class DMLServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
      
    Connection connection = null;
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			PrintWriter out = response.getWriter();
			out.println("<html><body>");
			
			// Load the DB properties from the config file
	 		InputStream in = getServletContext().getResourceAsStream("details");

	 		Properties props = new Properties();
	 		props.load(in);

	 		DML conn = new DML(props.getProperty("url"), props.getProperty("userid"),
	 				props.getProperty("password"));
			
	 		connection = conn.getConnection();
			
			Statement stmt = connection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
					ResultSet.CONCUR_READ_ONLY);
			stmt.executeUpdate("insert into eproduct(name, price,date_added) "
					+ "values('New Product',17700.44,now())");
			out.println("Executed an insert operation<br>");
			
			stmt.executeUpdate("update eproduct set price = 10000"
					+ "where ID = 5");
			out.println("Executed an update operation<br>");
			
			stmt.executeUpdate("delete from eproduct"
					+ "where name = 1");
			out.println("Executed an delete operation<br>");
			
			
				out.println("<html><body>");
				conn.closeConnection();
				
				
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
	}
	}
	

	

	


