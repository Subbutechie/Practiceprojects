package com;

import java.io.*;
import java.sql.*;
import java.util.Properties;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

@WebServlet("/init")
public class JDBCInit extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		 PrintWriter out = response.getWriter();
         out.println("<html><body>");
         
         // Load the DB properties from the config file
         InputStream in = getServletContext().getResourceAsStream("Config.properties");
         
         Properties props = new Properties();
         props.load(in);
         
         DBUtil dbutil = new DBUtil(props.getProperty("url"),
         props.getProperty("userid"), props.getProperty("password"));
         
         
         Connection connection = dbutil.getConnection();
         out.println("DB Connection initialized successfully!.<br>");
     }
}
 