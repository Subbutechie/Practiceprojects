package com;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Properties;

@WebServlet("/call")
public class StoredProcServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	Connection connection = null;
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws
	ServletException, IOException {
		try {
		PrintWriter out = response.getWriter();
		out.println("<html><body>");
		
		// Load the DB properties from the config file
 		InputStream in = getServletContext().getResourceAsStream("config.prop");

 		Properties props = new Properties();
 		props.load(in);

 		Connectdb conn = new Connectdb(props.getProperty("url"), props.getProperty("userid"),
 				props.getProperty("password"));
		
 		connection = conn.getConnection();
		System.out.println("DB Connection initialized successfully!.<br>");
		
			CallableStatement stmt = connection.prepareCall("{call add_product(?,?,?)}");
			stmt.setString(1, "new product");
			stmt.setBigDecimal(2, new BigDecimal(123.23));
			stmt.setString(3, "green");
			stmt.executeUpdate();
			
			out.println("Stored procedure has been executed");
			stmt.close();
			
			out.println("<html><body>");
			conn.closeConnection();
			
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	
	}
	
	
}
