package com;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

@WebServlet("/op")
public class OpServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
    Connection connection = null;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			PrintWriter out = response.getWriter();
			out.println("<html><body>");
			
			// Load the DB properties from the config file
	 		InputStream in = getServletContext().getResourceAsStream("config");

	 		Properties props = new Properties();
	 		props.load(in);

	 		ConnectOp conn = new ConnectOp(props.getProperty("url"), props.getProperty("userid"),
	 				props.getProperty("password"));
			
	 		connection = conn.getConnection();
			
			Statement stmt = connection.createStatement();
			stmt.executeUpdate("create database bikes");
			out.println("created database: bikes<br>");
			stmt.executeUpdate("use bikes");
			out.println("selected database: bikes<br>");
			stmt.executeUpdate("drop database bikes");
			out.println("Dropped database: bikes<br>");
			
			
				out.println("<html><body>");
				conn.closeConnection();
				
				
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
		
		}
	}


