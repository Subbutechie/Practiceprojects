package cookies;



import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

public class CookieCreator extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		PrintWriter out = response.getWriter();
		
		Cookie c1 = new Cookie("Userid", "Subbu");
		response.addCookie(c1);
		
		Cookie c2 = new Cookie("age", "23");
		response.addCookie(c2);

		out.println("Hello from CookieCreator.");

	}

}


