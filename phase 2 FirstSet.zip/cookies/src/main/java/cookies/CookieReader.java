package cookies;



import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

public class CookieReader extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		PrintWriter out = response.getWriter();

		// This servlet reads the cookies coming from browser
		Cookie[] cookies = request.getCookies();

		out.println("Found the following cookies coming from the user(browser)");
		for (Cookie c : cookies) {
			out.println(" cookie name is " + c.getName() + "and value is " + c.getValue());
		}

	}

}