package com;

import java.io.*;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

@WebServlet("/logout")
public class LogoutServ extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		HttpSession session = request.getSession();
		session.invalidate();

		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		out.println("Logged out of session.<br>");
		out.println("<a href='Login.html'>Click here to login again </a>");
	}

}