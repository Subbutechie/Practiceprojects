package com;


import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.GenericServlet;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
class MyGenericServlet extends jakarta.servlet.GenericServlet {
	private static final long serialVersionUID = 1L;

	public void service(ServletRequest req, ServletResponse res) throws ServletException, IOException {
		
		String sbasic = 
				req.getParameter("mname");
				res.setContentType("text/html"); 
				PrintWriter out =res.getWriter(); 
				out.print("<html><body>"); 
				out.print("Name:" + sbasic + 
				"<Br>"); 
				out.print("</body></html>"); 

	}

}