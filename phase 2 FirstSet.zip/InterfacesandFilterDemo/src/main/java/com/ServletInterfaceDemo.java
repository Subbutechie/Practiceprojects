package com;


import java.io.*;

import jakarta.servlet.*;
import jakarta.servlet.http.*;

public class ServletInterfaceDemo extends HttpServlet {
	private static final long serialVersionUID = 1L;
		
		public void init(ServletConfig config) throws ServletException {		
			super.init(config);
			
			//System.out.println("Inside init method");
			String strABC = config.getInitParameter("ABC");
			System.out.println("Initiazation parameter ABC = "+strABC);	
			
		}

		protected void doGet(HttpServletRequest request, HttpServletResponse response)
				throws ServletException, IOException {
			//System.out.println("Inside doGet method");
			
			PrintWriter out = response.getWriter();

			out.print("Response from ServletInterfacesDemo<br>");
			
			ServletContext sc = getServletContext();
			String strXYZ = sc.getInitParameter("XYZ");
			out.print(" XYZ Init parameter value is " +strXYZ);	
			// print the server name
			out.println("<br> I am deployed on " +sc.getServerInfo());
			
			// port on which this servlet is listening
			out.println("<br> I am listening on " +request.getServerPort());
			
			//parameters or query processing
			String name = request.getParameter("name");
			String age = request.getParameter("age");
			out.println("<br> <br>  Thank you,  " +name + ". You are "+age + " years old");

		
			
		}

		
		@Override
		public void destroy() {		
			super.destroy();
			System.out.println("Inside destroy method");
		}
	

}


